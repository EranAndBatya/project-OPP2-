#include "Enemy.h"



Enemy::Enemy()
{
}

Enemy::Enemy(const sf::Vector2f & pos)
	:Alive(pos)
{
}


Enemy::~Enemy()
{
}
