#include "Items.h"



Items::Items()
	
{
}

Items::Items(const sf::Vector2f & pos)
	:NoneAlive(pos)
{
}

Items::~Items()
{
}
