#include "NoneAlive.h"



NoneAlive::NoneAlive()
{
}

NoneAlive::NoneAlive(const sf::Vector2f& pos)
	:Creature(pos)
{
}


NoneAlive::~NoneAlive()
{
}
